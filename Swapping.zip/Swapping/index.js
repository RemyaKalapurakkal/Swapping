// import dependencies you will use
const express = require('express');
const path = require('path');
const fileUpload = require('express-fileupload');
const mongoose = require('mongoose');
const session = require('express-session');

//const bodyParser = require('body-parser'); // not required for Express 4.16 onwards as bodyParser is now included with Express
// set up expess validator
const {check, validationResult} = require('express-validator'); //destructuring an object

// connect to DB
mongoose.connect('mongodb://localhost:27017/Swapping',{
    useNewUrlParser: true,
    useUnifiedTopology: true
});

// define the model
const Card = mongoose.model('Card', {
    cName : String,
    cEmail : String,
    cImageName : String,
    cDescription : String
});

// define model for admin users
const User = mongoose.model('User', {
    uName: String,
    uPass: String
});

// set up variables to use packages
var myApp = express();

// set up the session middleware
myApp.use(session({
    secret: 'swapping',
    resave: false,
    saveUninitialized: true
}));

// set up the express file upload middleware to be used with Express
myApp.use(express.urlencoded({extended:false})); 
myApp.use(fileUpload()); 

// set path to public folders and view folders 
myApp.set('views', path.join( __dirname,'/views'));

//use public folder for CSS etc.
myApp.use(express.static(__dirname+'/public'));
myApp.set('view engine', 'ejs');

// render the login page
myApp.get('/',function(req, res){
    res.render('login'); // will render views/login.ejs
});

myApp.post('/login', function(req, res){
    // fetching data from login page
    var uName = req.body.uname;
    var uPass = req.body.upass;

    // finding if username and password same to the database
    User.findOne({uName: uName, uPass: uPass}).exec(function(err, user){
        console.log('Errors: ' + err);
        if(user){
            req.session.uName = user.uName;
            req.session.loggedIn = true;
            res.redirect('/dashboard');
        }
        else{
            res.redirect('/');
        } 
    });
});

// show all cards
myApp.get('/dashboard',function(req, res){
    if(req.session.loggedIn){
        Card.find({}).exec(function(err, cards){
            console.log(err);
            console.log(cards);
            res.render('dashboard', {cards:cards}); // will render views/allcards.ejs
        });
    }
    else{
        res.redirect('/');
    }
});


// start the server and listen at a port
myApp.listen(8080);

console.log('Everything executed fine.. website at port 8080....');


